package com.gmail.simon.ui.views.orderedit;

public class ProductInfoChangeEvent {

	public ProductInfoChangeEvent() {
		// Nothing to do here
	}
}
