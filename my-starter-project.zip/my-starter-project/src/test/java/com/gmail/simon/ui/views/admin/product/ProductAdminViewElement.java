package com.gmail.simon.ui.views.admin.product;

public class ProductAdminViewElement extends ProductAdminViewDesignElement implements CrudViewElement {

}