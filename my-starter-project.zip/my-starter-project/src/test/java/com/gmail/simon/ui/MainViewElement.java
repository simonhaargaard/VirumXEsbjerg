package com.gmail.simon.ui;

public class MainViewElement extends MainViewDesignElement {

}