package com.gmail.simon.ui.views.admin.user;

import com.gmail.simon.ui.views.admin.product.CrudViewElement;

public class UserAdminViewElement extends UserAdminViewDesignElement implements CrudViewElement {

}